/**
 * ProjectHour class can be considered a pair class, where there are pairs of Project+Hour
 * that can be used to handle assigning projects to an employee
 */
package cs450_project;

import java.math.BigDecimal;

public class ProjectHour {
	private String project;
	private BigDecimal pno;
	private double hours;

	public ProjectHour() {}

	public ProjectHour(String pName, double pHours) {
		this.project = pName;
		this.hours = pHours;
	}

	public String getProject() {return this.project;}

	public BigDecimal getProjectPno() {return this.pno;}

	public double getHours() {return this.hours;}

	public void setProject(String p) {this.project = p;}

	public void setProjectPno(BigDecimal p) {this.pno = p;}

	public void setHours(double parseDouble ) {this.hours = parseDouble;}
}
