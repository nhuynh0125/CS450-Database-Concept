/**
 * @author Ngoc Huynh
 * MyEmployee.java is a class implemented to handle all information of an employee and dependent
 * in the company
 * Here you can find the declaration of Employee and Dependent
 */
package cs450_project;
import java.text.SimpleDateFormat;
import java.util.*;

public class MyEmployee {
	private ArrayList<Dependent> dependent = new ArrayList<Dependent>();
	private ArrayList<ProjectHour> listOfAssignedProjects = new ArrayList<ProjectHour>();
	private String fname;
	private String middlename;
	private String lname;
	private String sex;
	private String address;
	private String birthdate;
	private String ssn;
	private String superSSN;
	private int salary;
	private int dno;
	private String email;

	public MyEmployee() {}

	public MyEmployee(String firstName, String middleName, String lastName, String sex, 
			String address, String ssn, String superSSN, String birthdate, int salary, int dno, String email) {
		this.fname = firstName;
		this.middlename = middleName;
		this.lname = lastName;
		this.sex = sex;
		this.superSSN = superSSN;
		this.address = address;
		this.ssn = ssn;
		this.birthdate = birthdate;
		this.salary = salary;
		this.dno = dno;
		this.email = email;
	}
		
	public String getFirstName() {return this.fname;}
	
	public String getMiddleName() {return this.middlename;}
	
	public String getLastName() {return this.lname;}
	
	public String getSSN() {return this.ssn;}
	
	public String getAddress() {return this.address;}
	
	public String getBirthDate() {return this.birthdate;}
	
	public String getSex() {return this.sex;}
	
	public String getSupervisorSSN() {return this.superSSN;}
	
	public int getSalary() {return this.salary;}
	
	public int getDepartmentNum() {return this.dno;}
	
	public String getEmail() {return this.email;}

	public ArrayList<ProjectHour> getAssignedProjects(){return this.listOfAssignedProjects;}
	
	public ArrayList<Dependent> getDependentInfo() {return this.dependent;}
	
	public String getProjectName(int index) {
		ProjectHour project = listOfAssignedProjects.get(index);
		return project.getProject();
	}
	
	public double getProjectHours(int index) {
		ProjectHour project = listOfAssignedProjects.get(index);
		return project.getHours();
	}
	
	public void setFirstName(String fname) {this.fname = fname;}
	
	public void setMiddleInitial(String minit) {this.middlename = minit;}
	
	public void setLastName(String lname) {this.lname = lname;}
	
	public void setSex(String sex) {this.sex = sex;}
	
	public void setAddress(String address) {this.address = address;}
	
	public void setBirthDate(String bdate) {this.birthdate = bdate;}
	
	public void setSSN(String ssn) {this.ssn = ssn;}
	
	public void setSupervisorSSN(String superssn) {this.superSSN = superssn;}
	
	public void setSalary(int salary) {this.salary = salary;}
	
	public void setDepartmentNumber(int dno) {this.dno = dno;}
	
	public void setEmail(String email) {this.email = email;}

	public void setAssignedProjects(ArrayList<ProjectHour> listOfProjects) {
		this.listOfAssignedProjects = listOfProjects;
	}
	
	public class Dependent {
		private String dependentName;
		private String dependentSex;
		private String dependentBirthdate;
		private String relationship;
		private java.sql.Date dateSQL;
		
		public Dependent() {}
		
		public Dependent( String name, String sex, String birthdate, String relationship) 
		{
			this.dependentName = name;
			this.dependentSex = sex;
			this.dependentBirthdate = birthdate;
			this.relationship = relationship;
		}
		
		public void setSQLBdate(String birthdate) {
			SimpleDateFormat formatDate = new SimpleDateFormat("DD-MM-YY");
			try {
				java.util.Date dateJava = formatDate.parse(this.getBirthDate());
				System.out.println("Date in Java: "+ dateJava);
				this.dateSQL = new java.sql.Date(dateJava.getTime());
			}
			catch(Exception z) {
				z.printStackTrace();
			}
		}

		public String getName() {return this.dependentName;}
		
		public String getSex() {return this.dependentSex;}
		
		public String getBirthDate() {return this.dependentBirthdate;}
		
		public java.sql.Date getDOBinSQL(){return this.dateSQL;}
		
		public String getRelationship() {return this.relationship;}	
	}
	/**
	 * Creates a Dependent and assigns it to the Employee's List of Dependents
	 * Also set the birthdate of this dependent accordingly to SQL Date
	 * @param dependent_firstname
	 * @param sex
	 * @param birthdate
	 * @param relationship
	 */
	public void setDependents(String dependent_firstname, String sex, String birthdate, String relationship) {
		Dependent myDependent = new Dependent(dependent_firstname, sex, birthdate, relationship);
		myDependent.setSQLBdate(birthdate);
		dependent.add(myDependent);
	}	
}
