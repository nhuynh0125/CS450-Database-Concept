/**
 * @author Ngoc Huynh
 * Question 1/Part1 of CS450 project can be found here
 * Please enter your own username and password to the database at line 18 and line 19
 */
package cs450_project;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Part1 {
	private static Connection myConnection;
	private static String DBINFO = "jdbc:oracle:thin:@apollo.vse.gmu.edu:1521:ite10g";
	private static String DBUSERNAME = "username";
	private static String DBPASSW = "password";
	private static String DRIVERNAME = "oracle.jdbc.driver.OracleDriver";
	private static PreparedStatement myStatement;

	public static void main(String[] args) throws SQLException, IOException {
		startConnection();
		System.out.println("Here is the answer for Part 1 of the project");
		System.out.println("--------------------------------------------");
		System.out.println("Retrieves the employees who work in the Research department\r\n" + 
				"and print the employee�s last name and their SSN:\r\n");
		problem11();
		System.out.println("\nRetrieves the employees who work in departments located in\r\n" + 
				"Houston and work on the project �ProductZ�. List their last name, SSN, and the number of hours\r\n" + 
				"that the employee works on that project:\r\n");
		problem12();
		myConnection.close();
	}

	private static void problem12() {
		try
		{
			myStatement = myConnection.prepareStatement("select Lname, Ssn, SUM(Hours) "
					+ "from EMPLOYEE, WORKS_ON "
					+ "where Dno in "
					+ "(select Dnumber from DEPT_LOCATIONS where Dlocation = ?) "
					+ "and Ssn = Essn "
					+ "and Pno in "
					+ "(select Pnumber from project where Pname = ?) "
					+ "group by Lname, Ssn" );

			myStatement.setString(1, "Houston");
			myStatement.setString(2, "ProductZ");
			ResultSet myResult = myStatement.executeQuery();
			System.out.println("Last Name" + "  SSN" + "       Total Hours");
			while(myResult.next()){
				String lname = myResult.getString("Lname");
				String ssn = myResult.getString("Ssn");
				float hours = myResult.getFloat("SUM(Hours)");
				System.out.println(lname + "    " + ssn + " "+ hours);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}


	private static void problem11() {
		try
		{
			myStatement=myConnection.prepareStatement("select Lname,Ssn from EMPLOYEE,DEPARTMENT where Dno = Dnumber and Dname = ?");
			myStatement.setString(1, "Research");
			ResultSet myResult=myStatement.executeQuery();

			while(myResult.next()){
				String Lname=myResult.getString("Lname");
				String Ssn=myResult.getString("Ssn");
				System.out.println(Lname +" " + Ssn);
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	private static void startConnection() throws SQLException {
		try {
			Class.forName(DRIVERNAME);
		} catch (ClassNotFoundException e) {
			System.out.println("Could not load the driver for the connection");
		}
		myConnection = DriverManager.getConnection(DBINFO, DBUSERNAME, DBPASSW);
	}

}
