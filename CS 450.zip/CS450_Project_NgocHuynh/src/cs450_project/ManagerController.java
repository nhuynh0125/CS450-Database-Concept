/**
 * @author Ngoc Huynh
 * This class is to handle all rules and conditions that can happen
 * when adding a new employee
 * EXTRA CREDIT methods can be found at the end of this class as well
 */
package cs450_project;

import javafx.event.*;
import javafx.fxml.*;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.scene.control.TextArea;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.collections.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

public class ManagerController {
	/**
	 * Variables from associated classes
	 */
	ProjectHour myPairofProjectHour;
	ProjectHour projectPair;
	MyCompany company;
	MyEmployee employee;

	/**
	 * Attributes for employee table:
	 * fname, minit, lname, ssn, bdate,
	 * address, sex, salary, superssn, dno, email
	 */
	@FXML
	private TextField fname_input;

	@FXML
	private TextField middleName_input;

	@FXML
	private TextField lname_input;

	@FXML
	private TextField ssn_input;

	@FXML
	private TextField birthdate_input;

	@FXML
	private TextField address_input;

	@FXML
	private TextField sex_input;

	@FXML
	private TextField salary_input;

	@FXML
	private TextField superssn_input;

	@FXML
	private ComboBox<String> departmentNumberBox;

	@FXML
	private TextField email_input;

	/**
	 * Attributes for works_on table:
	 * essn, pno, hours
	 */

	@FXML
	private TextField projectHour_input;

	@FXML
	private ComboBox<String> projectCombo;

	/**
	 * Attributes for dependent table:
	 * essn, dependent_name, sex, bdate, relationship
	 */
	@FXML
	private TextField dependent_fname_input;

	@FXML
	private TextField dependent_sex_input;

	@FXML
	private TextField dependent_bdate_input;

	@FXML
	private TextField dependent_relationship_input;

	/**
	 * Below variables are CheckBox, TextArea and Button that are
	 * used in the GUI
	 * TextArea databaseOutput - is where the output from the database will be
	 * CheckBox dependent_yes - Yes checkbox to indicate if there is a dependent
	 * CheckBox dependent_no - No checkbox to indicate if there is no dependent
	 * Button add_employee_button - Add Employee Button
	 * Button assign_project_button - Assign Project Button
	 * Button reset_project_button - Reset Project Button
	 * Button add_dependent_button - Add Dependent Button
	 */
	@FXML
	private TextArea output;

	@FXML
	private CheckBox dependent_yes;

	@FXML
	private CheckBox dependent_no;

	@FXML
	private Button add_employee_button;

	@FXML
	private Button assign_project_button;

	@FXML
	private Button remove_project_button;

	@FXML
	private Button add_dependent_button;

	@FXML
	private Button scan_employee_button;
	
	@FXML
	private Button delete_project_button;
	
	int counterAddedDependent = 0;
	boolean scanGood = false;
	private Alert myAlert = new Alert(AlertType.ERROR);
	private double sumHours = 0;
	private String missingAlert = "";
	private String outputString = "";
	private static final double MAX_NUMBER_OF_HOURS = 40.00;
	private ObservableList<String> listOfProjects = FXCollections.observableArrayList();
	private ObservableList<Integer> department_Numbers = FXCollections.observableArrayList();
	private ArrayList<Integer> listOfDepNums;
	private ArrayList<String> projectLists;
	private ArrayList<ProjectHour> projectsSelected = new ArrayList<ProjectHour>();



	/**
	 * Start the Manager Controller
	 * Here we will do the add employee, add project, add dependent and will check for 
	 * error accordingly
	 */
	@FXML
	protected void initialize() throws IOException {
		int listSize = 0;
		try {
			employee = new MyEmployee();
			company = new MyCompany();
			listOfDepNums = company.getDepartmentNumberList();
			for (int i = 0; i < listOfDepNums.size(); i++) {
				department_Numbers.add(listOfDepNums.get(i));
			}
			for (int i = 0; i < department_Numbers.size(); i++) {
				departmentNumberBox.getItems().add(department_Numbers.get(i).toString());
			}
			projectLists = company.getProjectList();
			assert projectLists.size() > 0;
			listSize = projectLists.size();
			for (int i = 0; i < listSize; i++) {
				listOfProjects.add(projectLists.get(i));
			}
			projectCombo.getItems().addAll(listOfProjects);

		} catch (SQLException se) {
			System.out.println("ERROR: Could not connect to the Database");
			System.exit(1);
		}
		/**
		 * EXTRA CREDIT
		 * Scan Button
		 * To make sure no employee violates the 2 constraints
		 * 1) An employee may not work on more than two projects managed by his/her department.
		 * 2) An employee must work on at least one project controlled by his/her department.
		 */
		scan_employee_button.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				scanEmployee();
			}
		});

		/**
		 * Add Employee Button
		 * call addEmployee() to handle the adding new employee
		 */
		add_employee_button.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				addEmployee();
			}
		});


		/**
		 * Assign Project Button
		 * Call addProject() to handle assigning new project
		 */
		assign_project_button.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				addProject();
			}
		});

		/**
		 * EXTRA CREDIT
		 * Delete EMPLOYEE from WORKS_ON
		 * If any violation was taken place, error alert will pop up
		 */
		remove_project_button.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				removeEmployeeFromWorkson();
			/**
				projectsSelected.clear();
				projectHour_input.clear();
				projectCombo.getSelectionModel().clearSelection();
				outputString = outputString
						+ "\nThe project is successfully removed from works_on without violating any contraint";
				output.setText(outputString);
				**/
			}
		});
		
		/**
		 * EXTRA CREDIT
		 * Delete a project from PROJECT
		 * if any violation was taken place, error alert will pop up
		 */
		delete_project_button.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				deleteProject();
			}
		});

		/**
		 * Add Dependent Button
		 * Call addDependent() to handle all the situations that can take place
		 */
		add_dependent_button.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				addDependent();
			}
		});

		/**
		 * When a user select checkbox Yes then this will handle the situation
		 * when there is no dependent to be added.
		 * If myNewValue is false then set not editable to all of dependent: first name, sex, birthdate and relation
		 * Else set them all as editable 
		 */
		dependent_yes.selectedProperty().addListener(new ChangeListener<Boolean>() {
			public void changed(ObservableValue<? extends Boolean> oldValue, Boolean myOldValue, Boolean myNewValue) {
				System.out.println(myNewValue);
				if (!myNewValue) {
					dependent_fname_input.setEditable(false);
					dependent_sex_input.setEditable(false);
					dependent_bdate_input.setEditable(false);
					dependent_relationship_input.setEditable(false);
				} else {
					dependent_fname_input.setEditable(true);
					dependent_sex_input.setEditable(true);
					dependent_bdate_input.setEditable(true);
					dependent_relationship_input.setEditable(true);
				}
			}
		});

		/**
		 * When a user select checkbox No then this will handle the situation
		 * when there is dependent to be added.
		 * If myNewValue is false then set editable and visible to all of dependent: first name, sex, birthdate and relation
		 * Else set them all as not editable and invisible
		 */
		dependent_no.selectedProperty().addListener(new ChangeListener<Boolean>() {
			public void changed(ObservableValue<? extends Boolean> oldValue, Boolean myOldValue, Boolean myNewValue) {
				System.out.println(myNewValue);
				if (!myNewValue) {
					dependent_fname_input.setEditable(true);
					dependent_sex_input.setEditable(true);
					dependent_bdate_input.setEditable(true);
					dependent_relationship_input.setEditable(true);

					dependent_fname_input.setVisible(true);
					dependent_sex_input.setVisible(true);
					dependent_bdate_input.setVisible(true);
					dependent_relationship_input.setVisible(true);
				} else {
					dependent_fname_input.setEditable(false);
					dependent_sex_input.setEditable(false);
					dependent_bdate_input.setEditable(false);
					dependent_relationship_input.setEditable(false);

					dependent_fname_input.setVisible(false);
					dependent_sex_input.setVisible(false);
					dependent_bdate_input.setVisible(false);
					dependent_relationship_input.setVisible(false);
				}
			}
		});
	}

	@FXML
	protected void handleYesBox() {
		if (dependent_yes.isSelected()) {
			dependent_no.setSelected(false);
		} 
	}

	@FXML
	protected void handleNoBox() {
		if (dependent_no.isSelected()) {
			dependent_yes.setSelected(false);
		} 
	}

	/**
	 * EXTRA CREDIT
	 * Create a new employee and use the user's input information to fill
	 * into this new employee's attributes.
	 * This method will check for any missing fields and give error alert if needed
	 * Else this will successfully add this employee to the database
	 */
	@FXML
	protected void scanEmployee() {
		output.setText("Be patient, your input is being checked . . .");
		missingAlert = "";
		try {
			if (fname_input.getText().isEmpty()) {
				missingAlert = missingAlert + "\nFirst Name is not entered";
			}
			if (middleName_input.getText().isEmpty()) {
				missingAlert = missingAlert + "\nMiddle Initial is not entered";
			}
			if (lname_input.getText().isEmpty()) {
				missingAlert = missingAlert + "\nLast Name is not entered";
			}

			if (ssn_input.getText().isEmpty()) {
				missingAlert = missingAlert + "\nEmployee SSN is not entered";
			}

			if (ssn_input.getText().length() != 9) {
				missingAlert = missingAlert + "\nSSN has to be 9-digits";
			}

			if (birthdate_input.getText().isEmpty()) {
				missingAlert = missingAlert + "\nEmployee Birthdate is not entered";
			}
			if (birthdate_input.getText().length() != 8) {
				missingAlert = missingAlert + "\nBirthdate format is dd-mm-yy";
			}
			if (address_input.getText().isEmpty()) {
				missingAlert = missingAlert + "\nAddress is not entered";
			}
			String sexInput = sex_input.getText();

			if (sexInput.isEmpty()) {
				missingAlert = missingAlert + "\nEmployee Sex is not entered";
			}
			else if (!sexInput.equals("F") && !sexInput.equals("f") && !sexInput.equals("M")
					&& !sexInput.equals("m")) {
				missingAlert = missingAlert + "\nInvalid, please enter with a character F or M";
			}

			if (salary_input.getText().isEmpty()) {
				missingAlert = missingAlert + "\nEmployee Salary is not entered";
			}
			if (superssn_input.getText().isEmpty()) {
				missingAlert = missingAlert + "\nSupervisor SSN is not entered";
			}
			if (superssn_input.getText().length() != 9) {
				missingAlert = missingAlert + "\nSupervisor SSN has to be 9-digits";
			}
			if (departmentNumberBox.getSelectionModel().getSelectedItem() == null) {
				missingAlert = missingAlert + "\nPlease make sure to select department number";
			}

			if (email_input.getText().isEmpty()) {
				missingAlert = missingAlert + "\nEmployee Email is not entered";
			}
			if (projectsSelected.size() == 0) {
				missingAlert = missingAlert + "\nAt least one project needs to be assigned before adding an employee";
			}

			else if (!atLeastOne(projectsSelected,
					Integer.parseInt(departmentNumberBox.getSelectionModel().getSelectedItem()))
					&& projectsSelected.size() > 0 ) {
				missingAlert = missingAlert + "\nPlease choose at least 1 project from the selected department";
			}

			if (projectHour_input.getText().isEmpty()) {
				missingAlert = missingAlert + "\nNumber of Hours for Project is not entered";
			}

			if (!dependent_yes.isSelected() && !dependent_no.isSelected()
					|| dependent_yes.isSelected() && dependent_no.isSelected()) {
				missingAlert = missingAlert + "\nPlease indicate has dependent or not";
			}

			if(dependent_yes.isSelected() && counterAddedDependent == 0) {
				missingAlert = missingAlert + "\nYou indicate that there is dependent "
						+ "but did not enter all info or add the dependent. Make sure correct all fields and add dependent too!";				
			}

			if (missingAlert.length() > 0) {
				scanGood = false;
				myAlert.setHeaderText("Error Alert");
				myAlert.setContentText(missingAlert);
				myAlert.showAndWait();
				missingAlert = "";
			}
			else {
				scanGood = true;
				missingAlert = missingAlert + "\n Great! This employee does not violate any contrainst!";
				myAlert.setHeaderText("Scan Employee Alert");
				myAlert.setContentText(missingAlert);
				myAlert.showAndWait();
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			cleanUp();
			clearGUIInput();
			myAlert.setTitle("Fatal Error");
			myAlert.setContentText(e.getMessage());
			myAlert.showAndWait();
		}

	}

	/**
	 * Add Employee Button
	 * Add this employee into the database
	 * @throws IOException 
	 * @throws SQLException 
	 */
	@FXML
	protected void addEmployee(){
		output.setText("Please make sure you enter your department and projects you will be assigned to." + "\n" + "Now be patient, your employee is being inserted into the database . . .");
		myAlert.setHeaderText("Check department and projects");
		myAlert.setContentText("Please make sure you have chosen a department and projects");
		myAlert.showAndWait();
		missingAlert = "";
		try {
			if(scanGood == false) {
				missingAlert = missingAlert + "\n Please hit the scan button and make sure everything is correct";
				myAlert.setHeaderText("Error Alert");
				myAlert.setContentText(missingAlert);
				myAlert.showAndWait();
				missingAlert = "";
			}
			else {
				employee.setFirstName(fname_input.getText());
				employee.setMiddleInitial(middleName_input.getText());
				employee.setLastName(lname_input.getText());
				employee.setAddress(address_input.getText());
				employee.setBirthDate(birthdate_input.getText());
				employee.setSex(sex_input.getText());
				employee.setSSN(ssn_input.getText());
				employee.setSupervisorSSN(superssn_input.getText());
				employee.setSalary(Integer.parseInt(salary_input.getText()));
				employee.setDepartmentNumber(
						Integer.parseInt(departmentNumberBox.getSelectionModel().getSelectedItem()));
				employee.setEmail(email_input.getText());
				employee.setAssignedProjects(projectsSelected);

				output.setText("Trying to connect to CS450 Database, please be patient . . . ");

				company.insertIntoEmployeeTable(employee);
				company.insertIntoWorksOn(employee);
				if (employee.getDependentInfo().size() > 0) {
					company.insertIntoDependents(employee);
				}
				reportResult(ssn_input.getText());
				cleanUp();
				clearGUIInput();
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			cleanUp();
			clearGUIInput();
			myAlert.setTitle("Fatal Error");
			myAlert.setContentText(e.getMessage());
			myAlert.showAndWait();
		}
	}
	
	/**
	 * EXTRA CREDIT
	 * Remove an employee from WORKS_ON
	 * Checking if removing this employee is allowed or not
	 */
	@FXML
	protected void removeEmployeeFromWorkson() {
		output.setText("Be patient, database is trying to removing this patient from WORKS_ON" + "\n" + "If any violation happened, there will be an alert");
		if(ssn_input.getText().isEmpty()) {
		myAlert.setHeaderText("Please make sure to enter an employee's ssn that you want to remove from WORKSON");
		myAlert.setContentText("Remove Employee");
		myAlert.showAndWait();
		}
		try {
			MyEmployee employeeToRemove = new MyEmployee();
			employeeToRemove = company.getEmployeeInformation(ssn_input.getText());
			output.setText(company.removeEmployeeFromWorksOn(employeeToRemove,company));
			cleanUp();
			clearGUIInput();
		}
		catch (Exception e) {
			e.printStackTrace();
			cleanUp();
			clearGUIInput();
			myAlert.setTitle("Fatal Error");
			myAlert.setContentText(" Violate child contraint, you might want to check and delete pno = pnumber from PROJECT table");
			myAlert.showAndWait();
		}
	}
	
	/**
	 * EXTRA CREDIT
	 * Delete a project from a PROJECT Button
	 * Checking if removing this employee is allowed or not
	 */
	@FXML
	protected void deleteProject() {
		String projectName;
		output.setText("Be patient, database is trying to check if deleting this project violates any rule...");
		try {
			projectName = projectCombo.getSelectionModel().getSelectedItem();

			if(projectName == null)
			{
				myAlert.setHeaderText("Please make sure to choose a project you want to delete");
				myAlert.setContentText("Delete Project");
				myAlert.showAndWait();
			}
			else {
			company.deleteProjectfromProject(projectName);
			cleanUp();
			clearGUIInput();
			}
		}
		catch (Exception e) {
			myAlert.setHeaderText("REFERENTIAL INTEGRITY CONSTRAINT");
			myAlert.setContentText("Attemped to delete a project from PROJECT table" + "\n" + "This is never allowed\n" + 
			"You are violating referential integrity constraint\n" + "I will suggest you to not delete any project from Project Table\n" +
					"or you can delete all employees work on such project first before trying to delete from PROJECT table\n");
			myAlert.showAndWait();
		}
	}
	/**
	 * Add Dependent Button
	 * When Add Dependent Button is chosen, this will check for any missing fields, any error.
	 * Give an error alert if there is something missing.
	 * Else it will successfully add a dependent
	 */
	@FXML
	protected void addDependent() {
		output.setText("Be patient, your input is being checked . . . ");
		missingAlert = "";
		try {
			if(!dependent_yes.isSelected() && !dependent_no.isSelected()) {
				missingAlert = missingAlert + "\nPlease make sure you enter all employee information, and select yes or no checkbox";
			}

			if(dependent_yes.isSelected() && dependent_bdate_input.getText().length() != 8 ) {
				missingAlert = missingAlert + "\nDependent date format is DD-MM-YY";
			}

			String dep_sexInput = dependent_sex_input.getText();

			if (dependent_yes.isSelected() && dep_sexInput.isEmpty()) {
				missingAlert = missingAlert + "\nPlease enter the dependent's sex";
			}
			else if (dependent_yes.isSelected() && (!dep_sexInput.equals("F") && !dep_sexInput.equals("f") && !dep_sexInput.equals("M")
					&& !dep_sexInput.equals("m"))) {
				missingAlert = missingAlert + "\nInvalid dependent sex, please enter with a character F or M";
			}

			if(dependent_yes.isSelected() && dependent_relationship_input.getText().isEmpty()) {
				missingAlert = missingAlert +"\nPlease enter a dependent's relation to the employee";
			}

			if(dependent_yes.isSelected() && dependent_fname_input.getText().isEmpty()) {
				missingAlert = missingAlert +"\nPlease enter a dependent's first name";
			}

			if(dependent_no.isSelected()) {
				missingAlert = missingAlert +"\nYou indicate that there is no dependent for this employee, can not add!";
			}

			if(missingAlert.length()>0) {
				myAlert.setHeaderText("Adding Dependent Error");
				myAlert.setContentText(missingAlert);
				myAlert.showAndWait();
				missingAlert ="";
			}

			else {
				counterAddedDependent++;
				employee.setDependents(dependent_fname_input.getText(), dependent_sex_input.getText(),
						dependent_bdate_input.getText(), dependent_relationship_input.getText());
				outputString = outputString + "\nDependent successfully added\n" + dependent_fname_input.getText() + " "
						+ dependent_sex_input.getText() + " " + dependent_bdate_input.getText() + " "
						+ dependent_relationship_input.getText();
				output.setText(outputString);
				dependent_fname_input.clear();
				dependent_sex_input.clear();
				dependent_bdate_input.clear();
				dependent_relationship_input.clear();
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			dependent_no.setSelected(false);
			dependent_yes.setSelected(false);
			dependent_fname_input.clear();
			dependent_sex_input.clear();
			dependent_bdate_input.clear();
			dependent_relationship_input.clear();
			myAlert.setTitle("Exception Error");
			myAlert.setContentText(e.getMessage());
			myAlert.showAndWait();
		}
	}

	/**
	 * Assign Project
	 * This is to handle when trying to assign a new project.
	 * This checks for if the employee ssn was entered first.
	 * If there are more than two projects were assigned for the employee's department
	 * If there is any duplicate projects
	 * If the number of hours exceeds 40 hours
	 */
	@FXML
	protected void addProject() {
		myPairofProjectHour = new ProjectHour();
		sumHours = 0.00;
		output.setText("Be patient, your input is being checked . . . ");

		try {
			myPairofProjectHour.setHours(Double.parseDouble(projectHour_input.getText()));
			myPairofProjectHour.setProject(projectCombo.getSelectionModel().getSelectedItem().toString());

			if(ssn_input.getText().isEmpty()) {
				projectsSelected.clear();
				myAlert.setHeaderText("No employee to assign project to");
				myAlert.setContentText("Please make sure to enter ssn first before adding project");
				myAlert.showAndWait();
			}
			else if(ssn_input.getText().length() != 9) {
				projectsSelected.clear();
				myAlert.setHeaderText("Employee SSN has to be exact 9-digits");
				myAlert.setContentText("Please reconfirm the employee ssn");
				myAlert.showAndWait();
			}

			projectsSelected.add(myPairofProjectHour);

			if(TwoProjectSameDepartment(projectsSelected,Integer.parseInt(departmentNumberBox.getSelectionModel().getSelectedItem()))) {
				projectsSelected.clear();
				myAlert.setHeaderText("Can not have more than 2 projects per department");
				myAlert.setContentText("No more than 2 projects can be assigned to an employee. Try again");
				myAlert.showAndWait();
			}

			if(exceedMaximumHour(projectsSelected)) {
				projectsSelected.clear();
				myAlert.setHeaderText("Hours assigned are more than max-hour allowed");
				myAlert.setContentText("No more than a total of 40 hours can be assigned to an employee. Try again");
				myAlert.showAndWait();
			}

			 if(projectDuplicate(projectsSelected) > 0) {
				int i = projectDuplicate(projectsSelected);
				projectsSelected.remove(i);
				myAlert.setHeaderText("Duplicate Project");
				myAlert.setContentText("Project selected has already been assigned.");
				myAlert.showAndWait();
			}
			else {
				outputString = outputString + "\n" + "Successfully assigned " + myPairofProjectHour.getProject() + " to Employee\t Hours: " + myPairofProjectHour.getHours();
				output.setText(outputString);
				projectCombo.getSelectionModel().clearSelection();
			}
		}
		catch (Exception e) {
			myAlert.setHeaderText("ERROR ADDING PROJECT");
			myAlert.setContentText("Attemped to add without selecting a PROJECT and/or a DEPARTMENT, please also make sure to choose a department as well");
			myAlert.showAndWait();
		}
	}

	/**
	 * This method is to check if total hours assigned to an employee
	 * is less than or equal 40 hours
	 * @param listofSelectedProjects
	 * @return true if <= 40 hours
	 * false if > 40 hours
	 */
	private boolean exceedMaximumHour(ArrayList<ProjectHour> listofSelectedProjects) {
		for (int i = 0; i < listofSelectedProjects.size(); i++) {
			projectPair = listofSelectedProjects.get(i);
			sumHours += projectPair.getHours();
			if (sumHours > MAX_NUMBER_OF_HOURS) {
				outputString = "";
				return true;
			}
		}
		return false;
	}

	/**
	 * This method checks if the newly assigned project is a duplicate of any of the
	 * previously assigned project	 * 
	 * @param listofSelectedProjects
	 * @return a number of duplication, if there is no duplication then the number
	 * return is 0
	 */
	private int projectDuplicate(ArrayList<ProjectHour> listofSelectedProjects) {
		ProjectHour projectName = new ProjectHour();
		int i;
		for (i = 0; i < listofSelectedProjects.size(); i++) {
			projectName = listofSelectedProjects.get(i);
			for (int j = ++i; j < listofSelectedProjects.size(); j++) {
				projectPair = listofSelectedProjects.get(j);
				if (projectName.getProject().equals(projectPair.getProject())) {
					return j;
				}
			}
		}
		return 0;
	}

	/**
	 * Clean up the selection of CheckBox or ComboBox
	 */
	private void cleanUp() {
		employee = new MyEmployee();
		projectLists.clear();
		dependent_no.setSelected(false);
		dependent_yes.setSelected(false);
		projectsSelected.clear();
		outputString = "";
	}

	/**
	 * Clears all of the GUI inputs
	 */
	private void clearGUIInput() {
		fname_input.clear();
		lname_input.clear();
		address_input.clear();
		projectHour_input.clear();
		middleName_input.clear();
		ssn_input.clear();
		superssn_input.clear();
		birthdate_input.clear();
		departmentNumberBox.getSelectionModel().clearSelection();
		projectCombo.getSelectionModel().clearSelection();
		salary_input.clear();
		sex_input.clear();
		email_input.clear();
	}

	private void reportResult(String ssn) {
		String myResult = "------REPORT TO EMPLOYEE FROM THE DATABASE------\n";
		MyEmployee myEmployee;
		MyEmployee.Dependent myDependent;
		ArrayList<ProjectHour> myProjectHour;

		try {
			myEmployee = company.getEmployeeInformation(ssn);
			myResult = myResult + "------Employee's Infomation------\n";
			myResult = myResult +
					"First name: " + myEmployee.getFirstName() + "\n" +
					"Middle name: " + myEmployee.getMiddleName() + "\n" +
					"Last name: " + myEmployee.getLastName() + "\n" +
					"SSN: " + myEmployee.getSSN() + "\n" +
					"Birthdate: " + myEmployee.getBirthDate()+ "\n" +
					"Address: " + myEmployee.getAddress() + "\n" +
					"Sex: " + myEmployee.getSex() + "\n" +
					"Salary: " + myEmployee.getSalary() + "\n" +
					"Supervisor SSN: " + myEmployee.getSupervisorSSN() + "\n" +
					"Department Number: " + myEmployee.getDepartmentNum() + "\n" +
					"Email: " + myEmployee.getEmail() + "\n";

			myResult = myResult + "------Project Assigned Information------\n";
			myResult = myResult + "Project Name - Hours: ";
			myProjectHour = company.getEmployeeProjects(myEmployee);
			for (int i = 0; i < myProjectHour.size(); i++) {
				myResult = myResult + myProjectHour.get(i).getProject() + "\t" + myProjectHour.get(i).getHours() + "\n";
			}
			company.getDependentsOfEmployee(myEmployee);
			if (myEmployee.getDependentInfo().size() > 0) {
				myResult = myResult + "------Dependents' Information----\n";
				for (int i = 0; i < myEmployee.getDependentInfo().size(); i++) {
					myDependent = myEmployee.getDependentInfo().get(i);
					myResult = myResult + "Name: " + myDependent.getName() + "\n" + 
							"Birthdate: " + myDependent.getBirthDate() + "\n" + 
							"Sex: " + myDependent.getSex() + "\n" +
							"Relationship: " + myDependent.getRelationship() + "\n";
				}
			}
			output.setText(myResult);
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	//--------------------------------------------------------
	/**
	 * EXTRA CREDIT
	 * 
	 * This method is implemented to check if at least one of the assigned project
	 * corresponds to the employee's selected department.
	 * This method will go into the database of the Company to check if the project
	 * number from works_on table is a match with a project number from
	 * the department table.
	 * 
	 * @param selectedProjects, dno
	 * @return true if at least one assigned project corresponds to the dno, false if
	 *         not
	 */
	private Boolean atLeastOne(ArrayList<ProjectHour> selectedProjects, int dno) {
		ArrayList<Integer> listOfProjectNumbers = new ArrayList<Integer>();
		String projectName = "";
		int myDno;
		for (int i = 0; i < selectedProjects.size(); i++) {
			projectName = selectedProjects.get(i).getProject();
			try {
				myDno = company.getDepartmentNumber(projectName);
				listOfProjectNumbers.add(myDno);
			} 
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (!listOfProjectNumbers.contains(dno)) {
			return false;
		}
		return true;
	}

	/**
	 * EXTRA CREDIT
	 * 
	 * This method is implemented to check if there is two assigned projects
	 * that is from the same department. 
	 * @param selectedProjects
	 * @param selectedDNO - the department number that is used to compared projects from
	 * @return true if there is two projects from same department
	 * 			false otherwise
	 */
	private Boolean TwoProjectSameDepartment(ArrayList<ProjectHour> selectedProjects, int selectedDNO) {
		int tempDNO = 0;
		int counter = 0;
		for (int i = 0; i < selectedProjects.size(); i++) {
			try {
				tempDNO = company.getDepartmentNumber(selectedProjects.get(i).getProject());
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
			if (tempDNO == selectedDNO)
				counter++;
			if (counter > 2)
				return true;
		}
		return false;
	}
}
