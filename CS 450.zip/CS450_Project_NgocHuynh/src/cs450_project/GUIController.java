/**
 * @author Ngoc Huynh
 * GUIController.java class - Implemented as a controller for GUIView.fxml
 */
package cs450_project;
import javafx.event.*;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.TextArea;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class GUIController {
	@FXML
	private TextArea database_output;

	@FXML
	private TextField ssn_input;

	@FXML
	Button login_button;

	private String ssn;

	private boolean validManager;

	/**
	 * Initialization method - implemented a call to the Manager View
	 * If the input SSN is not a valid manager SSN then the manager view will
	 * not be called. 
	 * Instead, an error message will be posted on the database message output
	 */
	@FXML
	protected void initialize() {
		login_button.setOnAction(new EventHandler<ActionEvent>() {
			Boolean result;
			public void handle(ActionEvent event) {
				Parent root;
				try {
					ssn = ssn_input.getText();
					MyCompany company = new MyCompany();
					validManager = company.isManager(ssn);
					if (validManager) {
						result = true;
						database_output.setText("Welcome to CS450 Company Database");
					}
					else {
						result = false;
					}

					if(result == false) {
						database_output.setText("You're not a manager as your SSN is not recognized in the Database");
					}
					else {
						root = FXMLLoader.load(getClass().getResource("ManagerView.fxml"));
						System.out.println(root);
						Stage stage = new Stage();
						stage.setTitle("Manager View");
						stage.setScene(new Scene(root, 800, 600));
						stage.show();
					}
				}
				catch(Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

}
