/**
 * MyCompany.java is implemented to handle all information of
 * -Employee
 * -ProjectHour
 * In this class, you can find these methods:
 * - isManager(): return true or false, check if the entered ssn is a valid manager
 * - getProjectList(): return a list of projects of an employee
 * - getProjectNumber(): return a project number from a given project name
 * - getDepartmentNumberList(): return a list of department
 * - getDepartmentNumber(): return a department number of a given project name
 * - getEmployeeInformation(): return all attributes of an employees from a given ssn
 * - getEmployeeProjects(): return all projects that an employee works on
 * - getDependentsOfEmployee(): return dependent(s) of an employee
 * - insertIntoEmployeeTable(): insert a given employee into Employee Table
 * - insertEmployeeIntoWorkson(): insert a given employee into Works_on Table
 * - removeEmployeeFromWorksOn(): remove an employee from Works_On table
 * - deleteProjectfromProject(): delete a project from Project Table
 * - insertIntoDependents(): insert Dependents into Dependent Table
 */
package cs450_project;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.io.*;
import java.util.*;
import java.math.BigDecimal;


public class MyCompany {
	SimpleDateFormat formatDate = new SimpleDateFormat("DD-MM-YY");
	private Connection myConnection;
	private PreparedStatement prepStatement;
	private ResultSet resultSet;
	private static String DBINFO = "jdbc:oracle:thin:@apollo.vse.gmu.edu:1521:ite10g";
	private static String DBUSERNAME = "nhuynh21";
	private static String DBPASSW = "ugleel";
	private static String DRIVERNAME = "oracle.jdbc.driver.OracleDriver";


	public MyCompany() throws SQLException, IOException {}

	public void initialization() throws SQLException, IOException {
		try {
			Class.forName(DRIVERNAME);
		}
		catch(ClassNotFoundException e) {
			System.out.println("Could not load the driver");
		}
		this.myConnection = DriverManager.getConnection(DBINFO, DBUSERNAME,DBPASSW);
	}

	/**
	 * Boolean method to check if the SSN corresponds to a manager in the database
	 * @param ssn
	 * @return true if it is, false if not
	 * @throws SQLException
	 */
	public boolean isManager(String ssn) throws SQLException {
		String myQuery = "select dname from department where mgrssn = ?";
		String managerSSN = "";
		try {
			initialization();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		prepStatement = myConnection.prepareStatement(myQuery);
		prepStatement.clearParameters();
		prepStatement.setString(1,ssn);
		resultSet = prepStatement.executeQuery();
		while(resultSet.next()) {
			managerSSN = resultSet.getString(1);
		}
		myConnection.close();
		resultSet.close();
		prepStatement.close();
		if(managerSSN.length() == 0 || managerSSN.isEmpty()) return false;
		return true;
	}

	/**
	 * Get a list of projects from the PROJECT table.
	 * @return the listOfProjects
	 * @throws SQLException
	 */
	public ArrayList<String> getProjectList() throws SQLException {
		try {
			initialization();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		ArrayList<String> listOfProjects = new ArrayList<String>();
		String myQuery = "select pname from project";
		String project = "";
		prepStatement = myConnection.prepareStatement(myQuery);
		prepStatement.clearParameters();
		resultSet = prepStatement.executeQuery();
		while(resultSet.next()) {
			project = resultSet.getString(1);
			listOfProjects.add(project);
		}
		prepStatement.close();
		resultSet.close();
		myConnection.close();
		return listOfProjects;

	}

	/**
	 * Grabs the Project Number from the given Project Name from the Database
	 * @param pName
	 * @return pno corresponding to the Project
	 * @throws SQLException
	 */
	public BigDecimal getProjectNumber(String pName) throws SQLException {
		try {
			initialization();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		String myQuery = "select pnumber from project where pname = ?";
		BigDecimal pno = null;
		prepStatement = myConnection.prepareStatement(myQuery);
		prepStatement.clearParameters();
		prepStatement.setString(1, pName);
		resultSet = prepStatement.executeQuery();
		while(resultSet.next()) {
			pno = resultSet.getBigDecimal(1);
		}
		prepStatement.close();
		resultSet.close();
		myConnection.close();
		return pno;

	}

	/**
	 * Grabs a list of available department numbers from the database
	 * @return  an ArrayList<Integer> of department numbers
	 * @throws SQLException
	 * @throws IOException
	 */
	public ArrayList<Integer> getDepartmentNumberList() throws SQLException, IOException{
		ArrayList<Integer> depNums = new ArrayList<Integer>();
		String myQuery = "select dnumber from department";
		initialization();
		prepStatement = myConnection.prepareStatement(myQuery);
		resultSet = prepStatement.executeQuery();
		while(resultSet.next()) {
			depNums.add(resultSet.getInt(1));
		}
		myConnection.close();
		prepStatement.close();
		resultSet.close();
		return depNums;

	}

	/**
	 * Get the department number corresponding to the project name
	 * @param pname
	 * @return dno - the project's corresponding department number
	 * @throws SQLException
	 */
	public int getDepartmentNumber(String pname) throws SQLException {
		int dno = 0;
		String myQuery = "select dnum from project where pname = ?";
		try {
			initialization();
		}
		catch(IOException e) {
			e.printStackTrace();			
		}
		prepStatement = myConnection.prepareStatement(myQuery);
		prepStatement.clearParameters();
		prepStatement.setString(1, pname);
		resultSet = prepStatement.executeQuery();
		while(resultSet.next()) {
			dno = resultSet.getInt(1);
		}
		resultSet.close();
		prepStatement.close();
		myConnection.close();

		return dno;
	}

	/**
	 * Returns an Employee object with it's field members assigned to the values the
	 * Employee table has in store for the given ssn queried.
	 * Return columns are (fname,minit,lname,ssn,bdate,address,sex,salary,superssn,dno,email)
	 * @param ssn - the employee to grab info about
	 * @return e - an employee object
	 */
	public MyEmployee getEmployeeInformation(String ssn) throws SQLException {
		MyEmployee employee = new MyEmployee();
		try {
			initialization();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		String myQuery = "select fname,minit,lname,ssn,bdate,address,sex,salary,superssn,dno,email from EMPLOYEE where ssn = ?";
		prepStatement = myConnection.prepareStatement(myQuery);
		prepStatement.clearParameters();
		prepStatement.setString(1, ssn);
		resultSet = prepStatement.executeQuery();
		while(resultSet.next()) {
			employee.setFirstName(resultSet.getString(1));
			employee.setMiddleInitial(resultSet.getString(2));
			employee.setLastName(resultSet.getString(3));
			employee.setSSN(resultSet.getString(4));
			employee.setBirthDate(resultSet.getString(5));
			employee.setAddress(resultSet.getString(6));
			employee.setSex(resultSet.getString(7));
			employee.setSalary(resultSet.getInt(8));
			employee.setSupervisorSSN(resultSet.getString(9));
			employee.setDepartmentNumber(resultSet.getInt(10));
			employee.setEmail(resultSet.getString(11));
		}
		resultSet.close();
		prepStatement.close();
		myConnection.close();

		return employee;
	}

	/**
	 * Get the Projects associated to the employee from the database
	 * @param e - Employee object
	 * @return ArrayList<Pair> type, an ArrayList of pairs
	 * @throws SQLException
	 * @throws IOException
	 */
	public ArrayList<ProjectHour> getEmployeeProjects(MyEmployee employee) throws SQLException, IOException {
		ArrayList<ProjectHour> list = new ArrayList<ProjectHour>();
		initialization();
		String pnoQuery = "select pno,hours from works_on where essn = ?";
		String pnameQuery = "select pname from project where pnumber = ?";
		prepStatement = myConnection.prepareStatement(pnoQuery);
		prepStatement.clearParameters();
		prepStatement.setString(1, employee.getSSN());
		resultSet = prepStatement.executeQuery();
		while(resultSet.next()) {
			ProjectHour myProjectHour = new ProjectHour();
			myProjectHour.setProjectPno(resultSet.getBigDecimal(1));
			myProjectHour.setHours(resultSet.getBigDecimal(2).doubleValue());
			list.add(myProjectHour);
		}
		prepStatement.close();
		prepStatement = myConnection.prepareStatement(pnameQuery);
		for(int i = 0; i<list.size(); i++) {
			prepStatement.clearParameters();
			prepStatement.setBigDecimal(1, list.get(i).getProjectPno());
			resultSet = prepStatement.executeQuery();
			while(resultSet.next()) {
				list.get(i).setProject(resultSet.getString(1));
			}
		}
		prepStatement.close();
		resultSet.close();
		myConnection.close();
		return list;
	}

	/**
	 * Modifies the employee object to set the Employee's dependents.
	 * 	Uses setDependents() from the Employee class to append Dependents to
	 *  the passed  employee object
	 * @param e - Employee object whose dependent field member needs to be modified
	 * @throws SQLException
	 */
	public void getDependentsOfEmployee(MyEmployee employee) throws SQLException { 
		try {
			initialization();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		String myQuery = "select dependent_name, sex, bdate, relationship"
				+ " from dependent where essn = ?";
		prepStatement = myConnection.prepareStatement(myQuery);
		prepStatement.clearParameters();
		prepStatement.setString(1, employee.getSSN());
		resultSet = prepStatement.executeQuery();
		while(resultSet.next()) {
			employee.setDependents(resultSet.getString(1), 
					resultSet.getString(2), 
					resultSet.getDate(3).toString(), 
					resultSet.getString(4));
		}
		prepStatement.close();
		resultSet.close();
		myConnection.close();
	}

	/**
	 * This prepares all the Employee field members into appropriate oracle Datatypes
	 * if necessary. Then inserts the contents of the employee object into the DB
	 * @param employee - of Employee type
	 * @throws SQLException
	 */
	public void insertIntoEmployeeTable(MyEmployee employee) throws IOException {
		BigDecimal numberSalary = new BigDecimal(employee.getSalary());
		BigDecimal numberDeptNum = new BigDecimal(employee.getDepartmentNum());
		java.sql.Date sqlDate = null;
		try {
			java.util.Date javaDate = formatDate.parse(employee.getBirthDate());
			sqlDate = new java.sql.Date(javaDate.getTime());
		}
		catch(Exception z) {
			z.printStackTrace();
		}

		String myQuery = "insert into employee values(?,?,?,?,?,?,?,?,?,?,?)";

		try {
			initialization();
			prepStatement = myConnection.prepareStatement(myQuery);
			prepStatement.clearParameters();
			prepStatement.setString(1, employee.getFirstName());
			prepStatement.setString(2, employee.getMiddleName());
			prepStatement.setString(3, employee.getLastName());
			prepStatement.setString(4, employee.getSSN());
			prepStatement.setDate(5, sqlDate);
			prepStatement.setString(6, employee.getAddress());
			prepStatement.setString(7, employee.getSex());
			prepStatement.setBigDecimal(8, numberSalary);
			prepStatement.setString(9, employee.getSupervisorSSN());
			prepStatement.setBigDecimal(10, numberDeptNum);
			prepStatement.setString(11, employee.getEmail());
			prepStatement.executeUpdate();
			myConnection.close();
			prepStatement.close();
			resultSet.close();
		}
		catch(SQLException e) {
			System.out.println("ERROR CODE: "+ e.getErrorCode());
			System.out.println(e.getSQLState());
			System.out.println(e.getCause());
			System.out.println(e.getMessage());
			System.out.println(e.getStackTrace());

		}
	}

	/**
	 * This will fill in project name and hours each project from the listOfProjects
	 * then grab each project number to that project 
	 * It will then create and put into an object type of ProjectPair(Pno,Hours).
	 * Lastly, it will make a list of ProjectPairs, and then for each pair
	 * insert one by one into the table
	 * @param employee
	 */
	public void insertIntoWorksOn(MyEmployee employee) throws SQLException, IOException {

		ArrayList<ProjectPair> numOfProjects = new ArrayList<ProjectPair>();
		String pName = null;
		BigDecimal pno;
		BigDecimal hour;
		String insertQuery = "insert into works_on(essn,pno,hours) values(?,?,?)";

		for(int i = 0; i<employee.getAssignedProjects().size();i++) {
			pName = employee.getProjectName(i);
			pno = getProjectNumber(pName);
			hour = new BigDecimal(employee.getProjectHours(i));
			ProjectPair myProjectHour = new ProjectPair(pno, hour);
			numOfProjects.add(myProjectHour);
		}

		initialization();
		for(int i = 0; i<numOfProjects.size();i++) {
			prepStatement = myConnection.prepareStatement(insertQuery);
			prepStatement.clearParameters();
			prepStatement.setString(1,employee.getSSN());
			prepStatement.setBigDecimal(2, numOfProjects.get(i).getProjectNumber());
			prepStatement.setBigDecimal(3, numOfProjects.get(i).getProjectHour());
			prepStatement.executeUpdate();
		}
		prepStatement.close();
		myConnection.close();

	}
	/**
	 * Remove Employee from Works_On
	 * @param employeeToRemove
	 * @throws SQLException 
	 * @throws IOException 
	 */
	public String removeEmployeeFromWorksOn(MyEmployee employeeToRemove, MyCompany company) throws SQLException, IOException {
		String returnString = "";
		String removeQuery = "delete from works_on where essn = ?";
		try {
			initialization();
			if(company.getEmployeeProjects(employeeToRemove).isEmpty()) {
				returnString = "No such employee in the WORKS_ON table to be removed!";
			}
			else {
			prepStatement = myConnection.prepareStatement(removeQuery);
			prepStatement.clearParameters();
			prepStatement.setString(1, employeeToRemove.getSSN());
			resultSet = prepStatement.executeQuery();
			returnString = "Remove successfully";
			resultSet.close();
			prepStatement.close();
			myConnection.close();
			}
		}
		catch(IOException e) {
			returnString = "Fatal Error";
			e.printStackTrace();			
		}
		return returnString;
	}

	/**
	 * Delete a Project from Project Table
	 * Will always show constraint violation alert
	 * @throws SQLException 
	 * @throws IOException 
	 */
	public void deleteProjectfromProject(String projectName) throws SQLException, IOException {
		String deleteQuery = "delete from project(pname) values(?)";
		initialization();
		prepStatement = myConnection.prepareStatement(deleteQuery);
		prepStatement.clearParameters();
		prepStatement.setString(1,projectName);
		prepStatement.executeUpdate();		

		prepStatement.close();
		myConnection.close();
	}

	/**
	 * Inserts into the Dependent table the dependents of the given employee
	 * @param employee - the employee
	 * @throws SQLException
	 */
	public void insertIntoDependents(MyEmployee employee) throws SQLException, IOException {
		ArrayList<MyEmployee.Dependent> dependentList;
		MyEmployee.Dependent dependent;
		String myQuery = "insert into dependent(essn,dependent_name,sex,bdate,relationship)"
				+ "values(?,?,?,?,?)";

		initialization();

		dependentList = employee.getDependentInfo();

		for(int i = 0; i<dependentList.size();i++) {
			dependent = dependentList.get(i);
			prepStatement = myConnection.prepareStatement(myQuery);
			prepStatement.clearParameters();
			prepStatement.setString(1, employee.getSSN());
			prepStatement.setString(2, dependent.getName());
			prepStatement.setString(3, dependent.getSex());
			prepStatement.setDate(4, dependent.getDOBinSQL());
			prepStatement.setString(5,dependent.getRelationship());
			prepStatement.executeUpdate();
		}
		prepStatement.close();
		myConnection.close();
	}

	/**
	 * Project Pair is a pair of Project Number and Project Hours
	 * @author Ngoc Huynh
	 */
	private class ProjectPair  {
		private BigDecimal project_number;
		private BigDecimal project_hour;

		private ProjectPair(BigDecimal pno, BigDecimal hours) {
			this.project_number = pno;
			this.project_hour = hours;
		}

		private BigDecimal getProjectNumber() {return this.project_number;}

		private BigDecimal getProjectHour() {return this.project_hour;}
	}




}
